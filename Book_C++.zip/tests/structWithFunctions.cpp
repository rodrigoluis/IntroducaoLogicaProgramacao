#include <iostream>
#include <cstring>
using namespace std;

struct ficha
{
   char nome[100];
   int idade;

   void insereDados(const char nomeIn[], int idadeIn)
   {
      strcpy(nome, nomeIn);
      idade = idadeIn;
   }

   void imprimeDados()
   {
      cout << "Nome: " << nome << endl;
      cout << "Idade: " << idade << endl << endl;
   }
};

int main()
{
   ficha f1, f2;

   f1.insereDados("Ana Paula", 22);
   f2.insereDados("João da Silva", 19);

   cout << "\nDados inseridos\n\n";
   f1.imprimeDados();
   f2.imprimeDados();
   return 0;
}
