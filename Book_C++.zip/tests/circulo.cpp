#include <iostream>
#include <cmath>
using namespace std;

class Circulo {
   private:
      float raio = 0;
   
   public:
      void setRaio(float r)
      {
         if(r <= 0)
         {
            cout << "Valor deve ser maior do que zero." << endl;
            return;
         }
         raio = r;
      }
      void imprimeArea() {
         float area;
         if(raio)
         {
            area = raio * raio * M_PI;
            cout << "Área do círculo: " << area << endl;
         }
         else
            cout << "O raio do círculo ainda não foi atribuído." << endl;
      }
};
   
int main()
{
   Circulo c1;
   float raio;
   cout << "Informe o raio do círculo: ";
   cin >> raio;
   c1.setRaio(raio);

   cout << "\nInforme o raio do círculo: ";
   cin >> raio;
   c1.setRaio(raio);
   c1.imprimeArea();
}
