
#include <iostream>
#include <cmath>
using namespace std;

class Ponto
{
   public:
      float x, y;
};

class Linha
{
   private:
      Ponto p1, p2;
   public:
      void setP1(float x, float y)
      {
         p1.x = x;
         p1.y = y;
      }
      void setP2(float x, float y)
      {
         p2.x = x;
         p2.y = y;
      }
      float getSize()
      {
         return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2));
      }
};

int main()
{
    Linha l1;
    l1.setP1(2.0, 3.0);
    l1.setP2(4.0, 7.5);
    cout << "Comprimento da linha: " << l1.getSize() << endl;
    return 0;
}
