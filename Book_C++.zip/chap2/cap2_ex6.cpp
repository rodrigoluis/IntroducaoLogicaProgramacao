/*
Make an algorithm to generate and print 
the result of H = 1 + 1/2 + 1/3 + 1/4 + 1/5.
*/

#include <iostream>
using namespace std;

int main()
{
    float H;    

    H = 1 + 1/2.0 + 1/3.0 + 1/4.0 + 1/5.0;

    cout << "H = " << H << endl;
    return 0;
}
